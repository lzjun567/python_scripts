# 国旗头像生成

[源代码](./__init__.py)

![](./new_avatar.jpg)
